<html>  
<head>  
    <title>Login Form</title>  
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  

</head>
<style>
 .box
 {
  width:100%;
  max-width:600px;
  background-color:#f9f9f9;
  border:1px solid #ccc;
  border-radius:5px;
  padding:16px;
  margin:0 auto;
 }
 .error
{
  color: red;
  font-weight: 700;
} 
</style>
<body>  
  <?php
  $nameError="";

  $emailError="";
  $passwordError="";
   if(isset($_POST["submit"]))
   {
    $name=$_POST['name'];
    $email=$_POST['email'];
    $password=$_POST['password'];
   }
   if(empty($name) )
   {
      $nameError = "name is requide";
   }else{
     $name = trim($name);
     $name = htmlspecialchars($name);
     if(!preg_match("/^[a-zA-Z ]+$/",$name))
     {
      $nameError = "name shuld only char";
     }

    }

     if(empty($email) )
     {
        $emailError = "email is requide";
     }else{
       $email = trim($email);
       $name = htmlspecialchars($email);
       if(!preg_match("/^[a-z@.___]+$/",$email))
       {
        $emailError = "invelid email";
       }

      }


       if(empty($password) )
       {
          $passwordError = "password is requide";
       }else{
         echo("ghghjg");
         if(strlen($password)<=8)
         {
          $passwordError = "At least 8 digits";

         }
         elseif(!preg_match("#[0-9]+#",$password))
         {
          $passwordError = "At least one digits";
         }
         
         elseif(!preg_match("#[A-Z]+#",$password))
         {
          $passwordError = "At least one uuper case char ";
         }
         elseif(!preg_match("#[a-z]+#",$password))
         {
          $passwordError = "At least one small case char ";
         }
         
      




   }
  
  ?>


    <div class="container">  
    <div class="table-responsive">  
    <h3 align="center">Login Form</h3><br/>
     <div class="box">
   <form id="validate_form" method="post" action="log.php" >
     <div class="form-group">
       <label for="name">Name</label>
       <input type="text" name="name" placeholder="Enter Name" class="form-control" value="<?php if(isset($name)){ echo $name; }?>"required/>
       <span class="text-danger" style="color:red;"><?php echo $nameError?></span>
      </div> 
      
       <div class="form-group">
       <label for="email">Email</label>
       <input type="text" name="email" placeholder="Enter Email" class="form-control" value=""required/>

       <span class="text-danger" style="color:red;"><?php echo $emailError?></span>
      </div>
      <div class="form-group">
       <label for="password">PASSWORD </label>
       <input type="password" name="password" id="password" placeholder="Enter password" class="form-control" value="" required />
       <span class="text-danger" style="color:red;"><?php echo $passwordError ?></span>
      </div>
      <div class="form-group">

        <button type="submit" class="btn btn-success" a href="">submit</a></button>
   
     
       </div>
       <p class="error"></p>
     </form>
    
     </div>
   </div>  
  </div>
 </body>  
 
</html>