<?php
$host = "localhost";
$username = "root";
$password = "";
$db = "eliterides";

$con = mysqli_connect($host, $username, $password, $db);

if($con === false) {
    die("Connection failed: " . mysqli_connect_error());
}

if($_SERVER["REQUEST_METHOD"] == "POST") {
    $input_username = mysqli_real_escape_string($con, $_POST["username"]);
    $input_password = mysqli_real_escape_string($con, $_POST["PASSWORD"]);

    // Use prepared statements to prevent SQL injection
    $sql = $con->prepare("SELECT * FROM admin WHERE username = ? AND password = ?");
    $sql->bind_param("ss", $input_username, $input_password);
    $sql->execute();
    $result = $sql->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        
        // Validate the admin credentials
        if ($row["username"] == "EliteRide101" && $row["PASSWORD"] == "Yuvraj@0208") {
            
             header("Location: admin-panel/dashboard.php?passengers");
        }
    } else {
        echo "Username and password incorrect";
    }
    $sql->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin Login Page</title>
    <link rel="shortcut icon" href="images/icon.png"/>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .login-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 300px;
        }
        .login-container h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        .login-container input[type="text"], .login-container input[type="password"] {
            width: 90%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 10px;
        }
        .login-container input[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #28a745;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .login-container input[type="submit"]:hover {
            background-color: blue;
        }
        .error {
            color: red;
            text-align: center;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    
    <div class="login-container">
        <h2>Login</h2>
        <form action="#" method="POST" autocomplete="off">
            <input type="text" name="username" placeholder="Admin Username" required>
            <input type="password" name="PASSWORD" placeholder="Password" required>
            <input type="submit" value="Login" name="login">
            <div class="">
                <br>
                <a href="#">Forget Password?</a>
            </div>
        </form>
    </div>
</body>
</html>
