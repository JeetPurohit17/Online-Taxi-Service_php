<?php
/*
include('../includes/connect.php');
include('../includes/function.php');


if (isset($_GET['name'])) {
    $parsedDriverId = $_GET['name'];

    $getDriverDetails = mysqli_query($con, "SELECT * FROM `contactus` WHERE name = $parsedDriverId");

    if (mysqli_num_rows($getDriverDetails) == 1) {

        deleteRecord($con, "DELETE FROM `contactus` WHERE name = $parsedDriverId");

        echo "<script>window.open('admin-panel.php?drivers','_self')</script>";
    }
}
    */
   

include('../includes/connect.php');
include('../includes/function.php');


	$eid=$_GET['name'];
		
	$query=mysqli_query($con, "delete from contactus where name='$eid'");
     
    if ($query) {
    echo "<script>alert('You have successfully deleted the data');</script>";
    echo "<script type='text/javascript'> document.location ='admin-panel.php?dashboard'; </script>";
  }
  else
    {
      echo "<script>alert('Something Went Wrong. Please try again');</script>";
    }
    ?>





