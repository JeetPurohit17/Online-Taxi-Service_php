<?php
include('../includes/connect.php');
include('../includes/function.php');


	$eid=$_GET['email'];
		
	$query=mysqli_query($con, "delete from loging where email='$eid'");
     
    if ($query) {
    echo "<script>alert('You have successfully deleted the data');</script>";
    echo "<script type='text/javascript'> document.location ='admin-panel.php?dashboard'; </script>";
  }
  else
    {
      echo "<script>alert('Something Went Wrong. Please try again');</script>";
    }
?>