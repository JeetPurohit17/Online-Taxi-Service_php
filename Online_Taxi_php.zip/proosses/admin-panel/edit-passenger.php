<?php

if(isset($_POST['s']))
{
	$eid=$_POST['bk_name'];
	$uname=$_POST['uname'];
	$Pass=$_POST['pass'];
	
	$query=mysqli_query($con, "update booking set bk_phone_contact='$uname',bk_pickup_suburb='$Pass' where bk_name='$eid'");
     
    if ($query) {
    echo "<script>alert('You have successfully update the data');</script>";
    echo "<script type='text/javascript'> document.location ='admin-panel.php?dashboard'; </script>";
  }
  else
    {
      echo "<script>alert('Something Went Wrong. Please try again');</script>";
    }
}




?>
<?php
$eid=$_GET['bk_name'];
$ret=mysqli_query($con,"select * from booking where bk_name='$eid'");
while ($row=mysqli_fetch_array($ret)) {
?>
<html>
<body>
<form name="add" method="post"  action="">
<input type="text" name="uname" value="<?php  echo $row['bk_phone_contact'];?>"placeholder="Phone Number" >
<input type="pass" name="pass" value="<?php  echo $row['bk_pickup_suburb'];?>" placeholder="Drop City">
<input type="text" name="bk_name" value="<?php  echo $eid;?>" hidden>
<?php 
}?>
<input type="submit" name="s" value="update" >
</form>
</body>
</html>