<?php
include('../includes/connect.php');
include('../includes/function.php');
@session_start();
// $number;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="shortcut icon" href="../images/icon.png"/>
</head>

<body>
    <div class="row justify-content-center  gap-5 p-4">
        <!-- Total Passengers Card -->
        <div class="card dashboard-card" style="width: 18rem">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="card-title fw-bold font-black">
                        Total Passengers
                    </h5>
                    <i class="fa-solid fa-users bg-secondary text-light p-2 rounded-5"></i>
                </div>

                <!-- PHP Code to Count the Total Passengers -->
                <?php
                // $number;
                $countTotalPassengers = mysqli_query($con, "SELECT COUNT(bk_number) AS total_passengers FROM `booking`");

                // * Fetch the result row as an associative array
                $row = mysqli_fetch_assoc($countTotalPassengers);

                // * Get the total count of passengers from the result
                $totalPassengers = $row['total_passengers'];

                $number = convertStringIntoInt($totalPassengers);
                ?>
                <h1 class="font-black"><?php echo $number; ?></h1>
                <a href="./admin-panel.php?passengers" class="card-link text-decoration-none">View All Passengers</a>
            </div>
        </div>

        <!-- Total Drivers Card -->
        <div class="card dashboard-card" style="width: 18rem">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="card-title fw-bold font-black">Total contact</h5>
                    <i class="fa-solid fa-id-card bg-secondary text-light p-2 rounded-5"></i>
                </div>

                <!-- PHP Code to Count the Total Passengers -->
                <?php
                $driverNumber;
                $countTotalDrivers = mysqli_query($con, "SELECT COUNT(name) AS total_drivers FROM `contactus`");

                // * Fetch the result row as an associative array
                $row = mysqli_fetch_assoc($countTotalDrivers);

                // * Get the total count of passengers from the result
                $totalDrivers = $row['total_drivers'];

                if ($totalDrivers <= 9) {
                    $driverNumber = "0" . $totalDrivers;
                } else {
                    $driverNumber = $totalDrivers;
                }
                ?>


                <h1 class="font-black"><?php echo $driverNumber; ?></h1>
                <a href="./admin-panel.php?drivers" class="card-link text-decoration-none">View All Contact</a>
            </div>
        </div>

       














        

            
        <!-- Completed reservations -->
        <div class="card dashboard-card" style="width: 18rem">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="card-title fw-bold font-black">Total Login</h5>
                    <i class="fa-solid fa-check bg-secondary text-light p-2 rounded-5"></i>
                </div>

                <!-- PHP Code to Count the Total Passengers -->
                <?php

                $countTotalCompletedState = mysqli_query($con, "SELECT COUNT(name) AS total_completed FROM `loging`");


                // * Fetch the result row as an associative array
                $row = mysqli_fetch_assoc($countTotalCompletedState);

                // * Get the total count of passengers from the result
                $totalCompleted = $row['total_completed'];

                $number = convertStringIntoInt($totalCompleted);
                ?>


                <h1 class="font-black"><?php echo $number; ?></h1>
                <a href="./admin-panel.php?completed_reservations" class="card-link text-decoration-none">View Details</a>
            </div>
        </div>

       
    </div>
</body>

</html>