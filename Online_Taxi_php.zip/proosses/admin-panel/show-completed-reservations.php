<?php
include('../includes/connect.php');
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Fav Icon -->
    <link rel="shortcut icon" href="../images/icon.png"/>
    <title>CONTACT US </title>

    <!-- Google Font (Sen) -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Sen:wght@400;500;600;700&display=swap" rel="stylesheet" />

    <!-- Just Validate Dev CDN -->
    <script src="https://unpkg.com/just-validate@latest/dist/just-validate.production.min.js"></script>

    <!-- Font Awesome CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />

    <!-- Bootsrap CSS -->
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css" />

    <!-- External CSS -->
    <link rel="stylesheet" href="../assets/css/style.css" />
    <link rel="stylesheet" href="../assets/css/style2.css">
</head>

<body class="bg-warning container-fluid">
    <h4 class="text-center container fw-bold font-black mt-5 pb-2">
        Total loging
    </h4>
    <div class="table-responsive overflow-x-scroll mt-3">
        <table class="table align-middle table-bordered">
            <thead class="text-center fw-semibold">
                <tr>
                  
                    <th class="background-black-color font-white">
                        Name
                    </th>
                    <th class="background-black-color font-white">Email</th>
                    <th class="background-black-color font-white">Password</th>
                    
                    <th class="background-black-color font-white">Action</th>

                </tr>
            </thead>
            <tbody>
                <?php
              
                $statusReadableFormat;
                $fetchDriverDetails = mysqli_query($con, "SELECT * FROM `loging`");

                while ($arrayOfDriverDetails = mysqli_fetch_assoc($fetchDriverDetails)) {
                    
                    $driverName = $arrayOfDriverDetails['name'];
                    $driverEmail = $arrayOfDriverDetails['email'];
                    $driverPhoneNo = $arrayOfDriverDetails['password'];
                    

                   



                ?>
                    <tr class="text-center">
                       
                        <td class="background-black-color-secondary font-white-secondary">
                            <?php echo $driverName; ?>
                        </td>
                        <td class="background-black-color-secondary font-white-secondary">
                            <a href="mailto:<?php echo $driverEmail; ?>" class="text-decoration-none font-white-secondary"><?php echo $driverEmail; ?></a>
                        </td>
                       
                        <td class="background-black-color-secondary font-white-secondary">
                            <a href="tel:<?php echo $driverPhoneNo; ?>" class="text-decoration-none font-white-secondary"><?php echo $driverPhoneNo; ?></a>
                        </td>
                        
                        
                        
                        <td class="background-black-color-secondary font-white-secondary">
                       
                            <a href='delete-profile.php?email=<?php echo $driverEmail; ?>' class='text-decoration-none font-white-secondary '><i class='fa-solid fa-trash-can'></i></a>

                        </td>
                    </tr>
                <?php
                    
                }

                ?>
            </tbody>
        </table>
    </div>
    <!-- Boostrap JavaScript Files -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js" integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT" crossorigin="anonymous"></script>

    <!-- JavaScript function to open Google Maps -->
   
</body>

</html>