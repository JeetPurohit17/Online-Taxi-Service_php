<?php

if(isset($_POST['s']))
{
	$eid=$_POST['name'];
	$uname=$_POST['uname'];
	$Pass=$_POST['pass'];
	
	$query=mysqli_query($con, "update contactus set phone='$uname',message='$Pass' where name='$eid'");
     
    if ($query) {
    echo "<script>alert('You have successfully update the data');</script>";
    echo "<script type='text/javascript'> document.location ='admin-panel.php?dashboard'; </script>";
  }
  else
    {
      echo "<script>alert('Something Went Wrong. Please try again');</script>";
    }
}




?>
<?php
$eid=$_GET['name'];
$ret=mysqli_query($con,"select * from contactus where name='$eid'");
while ($row=mysqli_fetch_array($ret)) {
?>
<html>
<body>
<form name="add" method="post"  action="">
<input type="text" name="uname" value="<?php  echo $row['phone'];?>"placeholder="Phone Number" >
<input type="pass" name="pass" value="<?php  echo $row['message'];?>"placeholder="Message">
<input type="text" name="name" value="<?php  echo $eid;?>" hidden>
<?php 
}?>
<input type="submit" name="s" value="update" >
</form>
</body>
</html>




