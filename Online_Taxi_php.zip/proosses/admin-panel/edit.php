<?php
include('democonnect.php');
if(isset($_POST['s']))
{
	$eid=$_POST['email'];
	$uname=$_POST['uname'];
	$Pass=$_POST['pass'];
	
	$query=mysqli_query($con, "update loging set name='$uname',password='$Pass' where email='$eid'");
     
    if ($query) {
    echo "<script>alert('You have successfully update the data');</script>";
    echo "<script type='text/javascript'> document.location ='demoview.php'; </script>";
  }
  else
    {
      echo "<script>alert('Something Went Wrong. Please try again');</script>";
    }
}




?>
<?php
$eid=$_GET['email'];
$ret=mysqli_query($con,"select * from loging where email='$eid'");
while ($row=mysqli_fetch_array($ret)) {
?>
<html>
<body>
<form name="add" method="post"  action="">
<input type="text" name="uname" value="<?php  echo $row['name'];?>" >
<input type="pass" name="pass" value="<?php  echo $row['password'];?>">
<input type="text" name="id" value="<?php  echo $eid;?>" hidden>
<?php 
}?>
<input type="submit" name="s" value="update" >
</form>
</body>
</html>