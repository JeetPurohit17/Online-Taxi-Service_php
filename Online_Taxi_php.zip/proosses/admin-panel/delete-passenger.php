<?php

include('../includes/connect.php');
include('../includes/function.php');


	$eid=$_GET['bk_name'];
		
	$query=mysqli_query($con, "delete from booking where bk_name='$eid'");
     
    if ($query) {
    echo "<script>alert('You have successfully deleted the data');</script>";
    echo "<script type='text/javascript'> document.location ='admin-panel.php?dashboard'; </script>";
  }
  else
    {
      echo "<script>alert('Something Went Wrong. Please try again');</script>";
    }
    ?>




