<?php


   $SERVER ="localhost";
    $name  = "root";
    $password = "";
    $dbname ="eliterides";

    
    $con = mysqli_connect($SERVER,$name,$password,$dbname);
    
        if(!$con)
        {
            echo "not connected";
        }
        
        
    $name  =$_POST['name'];
    $phone  =$_POST['phone'];
    $message =$_POST['message'];


    $sql ="INSERT INTO `contactus`(`name`, `phone`, `message`) VALUES ('$name','$phone','$message')";
    
    $result =mysqli_query($con , $sql);

    if($result)
    {
      
        header('Location: http://localhost/proosses/thankyou.html');
      

    }
    else
    {
        echo "query faild.....!";
    }
?>