<?php


   /* $SERVER ="localhost";
    $name  = "root";
    $password = "";
    $dbname ="eliterides";

    
    $con = mysqli_connect($SERVER,$name,$password,$dbname);
    
        if(!$con)
        {
            echo "not connected";
        }*/
        
        
    $name  =$_POST['name'];
    $email  =$_POST['email'];
    $password =$_POST['password'];


    $sql ="INSERT INTO `loging`(`Name`, `Email`, `PASSWORD`) VALUES ('$name','$email','$password')";
    
    /*$result =mysqli_query($con , $sql);

    if($result)
    {
       // http_response_code(301); 
        //header('Location: http://localhost/proosses/home.html');
      

    }
    else
    {
        echo "query faild.....!";
    }
        */
?>