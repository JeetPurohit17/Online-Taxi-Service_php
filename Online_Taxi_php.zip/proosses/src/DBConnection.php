<?php	
	    // DB connection details for localhost
    $sql_host = 'localhost';  
    $sql_user = 'root';       
    $sql_pass = '';           
    $sql_db   = 'eliterides';

    // Establish connection
    $db_conn = mysqli_connect($sql_host, $sql_user, $sql_pass, $sql_db);

    // Check connection
    if (!$db_conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    echo "Connected successfully";


?>