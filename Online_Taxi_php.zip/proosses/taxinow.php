<?php


    $SERVER ="localhost";
    $cartype  = "root";
    $password = "";
    $dbname ="loging";


    $con = mysqli_connect($SERVER,$name,$password,$dbname);
    
        if(!$con)
        {
            echo "not connected";
        }
        
    $name  =$_POST['name'];
    $dob  =$_POST['dob'];
    $email  =$_POST['email'];
    $password =$_POST['password'];


    $sql ="INSERT INTO `test`(`Name`, `Date of Birth`, `Email`, `PASSWORD`) VALUES ('$name','$dob','$email','$password')";
    
    $result =mysqli_query($con , $sql);

    if($result)
    {
        echo " Thank you your data submited";
    }
    else
    {
        echo "query faild.....!";
    }
?>